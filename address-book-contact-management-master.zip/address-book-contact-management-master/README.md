# A Java Project

**This is a simple java project from my early days as a Computer Science student**

_This programm was created for the second semester class Object-oriented Programming 
and is one of a few such simple java programms neccessary to pass the class_


> #### Description of project
>
>>A Java console application that manages an address book where the contacts are saved within an archive.

> #### Functionality
>
> 1. Print all available contacts
> 2. Add new contact
> 3. Search contact based on name
> 4. Search contact based on phone number
> 5. Edit contact based on name
> 6. Edit contact based on phone number
> 7. Delete contact based on name
> 8. Delete contact based on phone number
>

> #### About this project
>
> - The comments to make the code understandable, are within the archives
> - This project uses BufferedReader instead of FileReader
> - This program was written in Eclipse IDE
> - This repository was created to show the variety of the work I did and experience I gained as a student
>
